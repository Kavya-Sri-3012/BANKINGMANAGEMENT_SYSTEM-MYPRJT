package ServletClasses;


import java.io.IOException;

import DAO.RegisterDAO;
import DAO.UserDAO;
import Entity.User;
import HelperMethods.Helper;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Password check
        if (!password.equals(confirmPassword)) {
            request.setAttribute("error", "Passwords do not match!");
            request.getRequestDispatcher("register.jsp").forward(request, response);
            return;
        }

        // Generate random account number
        String accountNumber ="SB"+(long)(1000000000*Math.random());

        User user = new User();// 1000x 
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhoneNo(phone);
        user.setUsername(username);
        user.setPassword(password);
        user.setAccountNumber(accountNumber);
        user.setBalance(15000.0); // default initial balance

        RegisterDAO dao=new RegisterDAO();
        boolean success=false;
        try
        {
        	success = dao.registerUser(user);
        }
        catch(Exception e)
        {
        if (e.getMessage().contains("ORA-00001")) {
            // handle duplicate entry
        	 response.sendRedirect("index.jsp?msg=Email Already Exists..!");
        	  
        }
        }
        if (success) {
            response.sendRedirect("index.jsp?msg=Registration successful!");
        } else {
            request.setAttribute("error", "Registration failed. Try again!");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }
    
}
